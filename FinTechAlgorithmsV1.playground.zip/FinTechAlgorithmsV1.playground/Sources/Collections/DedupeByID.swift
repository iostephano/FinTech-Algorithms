//
//  DedupeByID.swift
//  
//  Created by Stephano Portella on 02/09/25.
//

import Foundation

public func dedupeByID(_ txs: [Tx]) -> [Tx] {
    var seen = Set<String>()
    var out: [Tx] = []
    for t in txs where !seen.contains(t.id) {
        seen.insert(t.id)
        out.append(t)
    }
    return out
}
