//
//  SortByDateAmount.swift
//  
//  Created by Stephano Portella on 02/09/25.
//

import Foundation

public func sortByDateAmount(_ txs: [Tx]) -> [Tx] {
    txs.sorted {
        if $0.date == $1.date { return $0.amount > $1.amount } // mismo día → monto descendente
        return $0.date < $1.date                               // fecha ascendente (antiguo→reciente)
    }
}
