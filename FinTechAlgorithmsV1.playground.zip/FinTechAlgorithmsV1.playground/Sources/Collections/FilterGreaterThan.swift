//
//  FilterGreaterThan.swift
//  
//  Created by Stephano Portella on 02/09/25.
//

import Foundation

public func filterGreaterThan(_ txs: [Tx], threshold: Decimal) -> [Tx] {
    txs.filter { $0.amount > threshold }
}
