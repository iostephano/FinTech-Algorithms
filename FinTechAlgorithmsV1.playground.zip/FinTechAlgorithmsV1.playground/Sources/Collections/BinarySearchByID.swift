//
//  BinarySearchByID.swift
//  
//  Created by Stephano Portella on 02/09/25.
//

import Foundation

public func binarySearchByID(_ txsSortedByID: [Tx], id: String) -> Int? {
    var lo = 0, hi = txsSortedByID.count - 1
    while lo <= hi {
        let mid = lo + (hi - lo)/2
        let midID = txsSortedByID[mid].id
        if midID == id { return mid }
        if midID < id { lo = mid + 1 } else { hi = mid - 1 }
    }
    return nil
}
