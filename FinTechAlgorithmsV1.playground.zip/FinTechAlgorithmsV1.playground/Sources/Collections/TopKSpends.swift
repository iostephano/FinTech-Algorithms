//
//  TopKSpends.swift
//  
//  Created by Stephano Portella on 02/09/25.
//

import Foundation

public func topKSpends(_ txs: [Tx], k: Int) -> [Tx] {
    guard k > 0 else { return [] }
    return Array(txs.sorted { $0.amount > $1.amount }.prefix(k))
}
