//
//  TestHelper.swift
//  
//
//  Created by Stephano Portella on 02/09/25.
//

import Foundation

@discardableResult
public func expect<T: Equatable>(_ got: T, _ expected: T, _ msg: String = "") -> Bool {
    let ok = (got == expected)
    print(ok ? "✅" : "❌", msg.isEmpty ? "\(got) == \(expected)" : msg)
    return ok
}
