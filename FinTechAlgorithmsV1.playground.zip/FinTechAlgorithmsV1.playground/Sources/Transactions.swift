//
//  Transactions.swift
//  
//
//  Created by Stephano Portella on 02/09/25.
//

import Foundation

public struct Tx: Hashable {
    public let id: String
    public let amount: Decimal
    public let date: Date
    public init(id: String, amount: Decimal, date: Date) {
        self.id = id
        self.amount = amount
        self.date = date
    }
}
