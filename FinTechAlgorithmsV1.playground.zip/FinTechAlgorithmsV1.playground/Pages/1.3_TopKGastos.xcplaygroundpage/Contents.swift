import Foundation

let now = Date()
let txs: [Tx] = [
    .init(id: "A", amount: 120, date: now),
    .init(id: "B", amount: 999, date: now),
    .init(id: "C", amount: 45,  date: now),
    .init(id: "D", amount: 300, date: now),
    .init(id: "E", amount: 501, date: now)
]

let top3 = topKSpends(txs, k: 3)
print("Top 3 por monto:", top3.map { "\($0.id): \($0.amount)" })
_ = expect(top3.map(\.id), ["B","E","D"], "Top 3 gastos")
