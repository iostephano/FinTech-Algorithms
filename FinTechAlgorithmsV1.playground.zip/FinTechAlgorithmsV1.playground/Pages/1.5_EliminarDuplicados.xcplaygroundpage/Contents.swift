import Foundation

let now = Date()
let txs: [Tx] = [
    .init(id: "A", amount: 10,  date: now),
    .init(id: "B", amount: 10,  date: now),
    .init(id: "A", amount: 10,  date: now), // duplicado
    .init(id: "C", amount: 99,  date: now),
    .init(id: "B", amount: 10,  date: now)  // duplicado
]

let clean = dedupeByID(txs)
print("Sin duplicados (preserva orden):", clean.map(\.id))
_ = expect(clean.map(\.id), ["A","B","C"], "Deduplicación por ID")
