import Foundation

let now = Date()
let txs: [Tx] = [
    .init(id: "TX01", amount: 10,  date: now),
    .init(id: "TX02", amount: 55,  date: now),
    .init(id: "TX03", amount: 7,   date: now),
    .init(id: "TX04", amount: 200, date: now)
]

// lista ordenada por id
let sortedByID = txs.sorted { $0.id < $1.id }
if let idx = binarySearchByID(sortedByID, id: "TX03") {
    print("Encontrado:", sortedByID[idx].id)
    _ = expect(sortedByID[idx].id, "TX03")
} else {
    print("No encontrado")
}
