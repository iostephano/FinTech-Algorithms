// FinTechAlgorithms – Parte 1: Manejo de colecciones y datos
//
// Explora los ejemplos en:
//   - Page 1.1: Ordenar transacciones
//   - Page 1.2: Filtrar por monto
//   - Page 1.3: Top K gastos
//   - Page 1.4: Buscar por ID
//   - Page 1.5: Eliminar duplicados
//
// Abre la barra lateral y selecciona cada Page para ejecutar el ejemplo.
