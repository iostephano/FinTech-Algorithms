import Foundation

let now = Date()
let txs: [Tx] = [
    .init(id: "A", amount: 100, date: now),
    .init(id: "B", amount: 250, date: now.addingTimeInterval(-86400)), // ayer
    .init(id: "C", amount: 80,  date: now.addingTimeInterval(-86400)), // ayer
    .init(id: "D", amount: 500, date: now.addingTimeInterval(-172800)) // anteayer
]

let sorted = sortByDateAmount(txs)
let f = DateFormatter(); f.dateStyle = .short; f.timeStyle = .short
print("Orden (antiguo→reciente, empate por monto desc):")
sorted.forEach { print("\($0.id): \($0.amount) • \(f.string(from: $0.date))") }

_ = expect(sorted.first?.id ?? "", "D", "La transacción más antigua debe ser D")
