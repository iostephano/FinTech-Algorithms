import Foundation

let now = Date()
let txs: [Tx] = [
    .init(id: "A", amount: 30,  date: now),
    .init(id: "B", amount: 250, date: now),
    .init(id: "C", amount: 120, date: now),
    .init(id: "D", amount: 60,  date: now)
]

let result = filterGreaterThan(txs, threshold: 100)
print("Mayores a 100:", result.map(\.id))
_ = expect(result.map(\.id), ["B","C"], "Filtrado > 100")
